import {oper} from "./switch";

console.log(oper)