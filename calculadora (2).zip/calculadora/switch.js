import {somar, subtrair, dividir, multiplicar} from './operacoes.js'
import {apresentarMensagem} from './utils.js'
import {questions} from './questions.js'

async function oper(opc){
    //Espera um resultado do usuário (await)
    let resp = await perguntar(questions)
    let opc = resp.opc
    let valor1 = parseInt (resp.n1)
    let valor2 = parseInt (resp.n2)


    switch (resp, opc) {
        case "+":
            let resSoma = somar(valor1, valor2)
            apresentarMensagem(resSoma, "SOMA")
            break;
        case "-":
            let resSub = subtrair(valor1, valor2)
            apresentarMensagem(resSub, "SUBTRAÇÃO")
            break;
        case "*":
            let resMult = multiplicar(valor1, valor2)
            apresentarMensagem(resMult, "MULTIPLICAÇÃO")
            break;
        case "/":
            let resDiv = dividir(valor1, valor2)
            apresentarMensagem(resDiv, "DIVISÃO")
            break;
        default:
            break;
        }
    return 
    }
export {oper}