function apresentarMensagem(valor, operacao){
    console.log(`A operacao de ${operacao} resultou em ${valor} `)
}

export {apresentarMensagem}