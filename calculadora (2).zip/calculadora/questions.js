// modulo externo
import inquirer from 'inquirer'  

var questions = [
    {
      type: 'input',
      name: 'opc',
      message: `Qual operação você deseja? \n
                  [+] Digite + para soma \n
                  [-] Digite - para subtração \n
                  [*] Digite * para multiplicação \n
                  [/] Digite / para divisão \n
              ` 
    },

    {
      type: 'input',
      name: 'n1',
      message: 'Digite o primeiro valor:'
    },
  
    {
      type: 'input',
      name: 'n2',
      message: 'Digite o segundo valor:'
    },
  ]

//Async: tem que esperar resposta externa do soft, junto com await
async function perguntar(){
    const resp = await inquirer.prompt(questions)
    return resp
}

export {questions, perguntar}
