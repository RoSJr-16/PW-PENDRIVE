const btn = document.getElementById("btn")
const form = document.getElementById("formulario")

btn.addEventListener("click", function(e) {
  e.preventDefault() // impede o formulário de recarregar a página

  let campo = {
    cep : form.cep.value,
    logradouro: form.logradouro.value,
    complemento: form.complemento.value,
    bairro : form.bairro.value,
    cidade: form.cidade.value,
    estado: form.estado.value
  }

  // Preenche os spans no resultado
  document.getElementById("r-cep").textContent = campo.cep
  document.getElementById("r-logradouro").textContent = campo.logradouro
  document.getElementById("r-complemento").textContent = campo.complemento
  document.getElementById("r-bairro").textContent = campo.bairro
  document.getElementById("r-cidade").textContent = campo.cidade
  document.getElementById("r-estado").textContent = campo.estado

  // Mostra a div de resultado
  document.getElementById("resultado").style.display = "block"
})


// carregamento
const loading = document.getElementById("loading")
//seleciona o cep q o usuário digitou e quando ele sair do campo o evento buscar cep irá acontecer
document.getElementById("cep").addEventListener("blur", buscarCep)

//função de validar cep
function validarCep(cep) {
//seleciona o cep q o usuário digitou e somente numeros
  cep = cep.replace(/\D/g, "")
//não deixa digitar um cep menor q 8
  if (cep.length !== 8) {
    alert("CEP inválido! Digite 8 números.")
    return null
  }
  return cep
}

//função pra buscar o cep
async function buscarCep() {
//seleciona o cep
  let cep = document.getElementById("cep").value
  cep = validarCep(cep)
  if (!cep) return

  // Mostra o loading enquanto busca
  loading.style.display = "inline"

  try {
    let url = `https://viacep.com.br/ws/${cep}/json/`
    let resp = await fetch(url)
    let dados = await resp.json()

    if (dados.erro) {
      alert("CEP não encontrado!")
      limparCampos()
      return
    }

    preencherCampos(dados)

  } catch (erro) {
    alert("Erro ao buscar CEP. Tente novamente!")
    console.error(erro)
    limparCampos()
  } finally {
    // Esconde o loading quando termina a requisição
    loading.style.display = "none"
  }
}

function preencherCampos(dados) {

  document.getElementById("logradouro").value = dados.logradouro
  document.getElementById("complemento").value = dados.complemento
  document.getElementById("bairro").value = dados.bairro
  document.getElementById("cidade").value = dados.localidade
  document.getElementById("uf").value = dados.uf
}

function limparCampos() {
  document.getElementById("logradouro").value = ""
  document.getElementById("complemento").value = ""
  document.getElementById("bairro").value = ""
  document.getElementById("cidade").value = ""
  document.getElementById("uf").value = ""
}

 document.getElementById("resultado").style.display = "block";