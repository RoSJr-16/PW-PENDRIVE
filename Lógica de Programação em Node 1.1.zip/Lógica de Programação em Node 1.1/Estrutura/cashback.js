let cash = 100, com = 5

if (com == 100.00){
    cash = com/100*5
}else if (com<1000.00){
    cash = com/100*80
}else if (com<2000.00){
    cash = com/100*10
}else if (com<5000.00){
    cash = com/100*15.5
}else{
    cash = com/100*15
}
console.log(cash)