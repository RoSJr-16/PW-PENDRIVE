let an = 2016, c

c = 2025-an
if(c<6 || c==6){
    console.log("Dente de leite")
}else if(c<10){
    console.log("Infantil 1")
}else if(c<14){
    console.log("Infantil 2")
}else if(c<16){
    console.log("Juvenil 1")
}else if(c<17){
    console.log("Juvenil 2")
}else{
    console.log("Não são permitidos maiores de 18 anos." )
}