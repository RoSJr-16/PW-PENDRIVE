let r = 3.000

if(r<=1.412){
    console.log("7,5%")
}else if(r>2.666){
    console.log("9%")
}else if(r>4.000){
    console.log("12%")
}else if(r>7.768){
    console.log("14%")
}else{
    console.log("16%")
}