let n1 = 2, n2= 4, n3 = 6, q1, q2, q3, total

q1 = n1*n1
q2 = n2*n2
q3 = n3*n3

total = q1+q2+q3

console.log(total)