import inquirer from 'inquirer'

var questionInver = [
    {
        type: 'input',
        name: 'a',
        message: `Insira o valor de A: `
    },

    {
        type: 'input',
        name: 'b',
        message: `Insira o valor de B: `
    },

    {
        type: 'input',
        name: 'c',
        message: `Insira o valor de C: `
    },
  ]

async function perguntar(){
    const resp = await inquirer.prompt(questionInver)
    return resp
}

export {questionInver, perguntar}