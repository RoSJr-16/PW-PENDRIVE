import {questionInver} from './questions'

async function invertido (){
    let a = 7, b = 5, c = 1
    c = a
    a = b
    b = c
    console.log(a)
    console.log(b)
}

export {invertido}