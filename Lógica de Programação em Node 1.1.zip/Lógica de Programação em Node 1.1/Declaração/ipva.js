let vv = 15.000, ipva

ipva = vv/100*4

console.log("O Vvalor do Ipva é " + (ipva))

