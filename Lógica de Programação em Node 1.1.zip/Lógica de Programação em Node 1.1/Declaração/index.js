import { invertido } from './invertido.js'
import { questionInver } from './questions'
import inquirer from 'inquirer'

console.log(invertido)