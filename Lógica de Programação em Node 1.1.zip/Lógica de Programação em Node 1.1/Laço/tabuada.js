//WHILE
let i = 0, n = 6, r

while (i<10) {
	console.log(i) 
	i = i+1
}