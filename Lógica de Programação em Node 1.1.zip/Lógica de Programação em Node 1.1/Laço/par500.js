//DO WHILE

let i=0

do{
    i=i+2
    console.log(i)
}while (i<500)