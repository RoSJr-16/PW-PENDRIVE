//FOR
let r = 0 
for(let i = 0; i<=100; i=i+1){
    console.log(i)
    r = i%10
    if (r==0){
        console.log("Esse número é divisivel por 10")
    }
}