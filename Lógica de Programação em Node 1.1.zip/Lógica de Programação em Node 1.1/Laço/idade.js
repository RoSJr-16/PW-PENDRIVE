//WHILE
let ano = 2024, anoNaci = 2004, idade, i = 0
while(i<7){
	idade = ano - anoNaci
	if(idade<18){
		console.log("Menor de idade")
	}else{
		console.log("Maior de idade")
	}
    i++
}