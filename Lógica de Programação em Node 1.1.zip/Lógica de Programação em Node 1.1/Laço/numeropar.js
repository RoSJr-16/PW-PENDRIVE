//FOR

for(let i = 2; i<201; i=i+2){
    console.log(i)
}