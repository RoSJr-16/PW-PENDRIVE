//WHILE
let aj = 1.56, ap = 1.78, i = 0  

while(aj<ap){
	aj = aj+0.025
	ap = ap+0.02
	i++
}
console.log("Se passaram " +i+ " anos")