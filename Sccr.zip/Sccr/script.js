let url = 'https://viacep.com.br/ws/01001000/json/'

let resp = await fetch(url)
let bd = await resp.json()

console.log(bd)